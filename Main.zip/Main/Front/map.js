var ToSend = {
  "startLat" : 0,
  "startLng" : 0,
  "endLat" : 0,
  "endLng" : 0

};


var rezponse = {

	"totalD": 323451.55,
	"info" : [
		{ "lat": 5.57432, "lng": -0.179432},
		{ "lat": 5.57732, "lng": -0.175432},
		{ "lat": 5.54432, "lng": -0.17882}
		],
	"sentences" :[
		{"sentence" : "Pick a car from osu to accra"},
		{"sentence" : "Pick a car from accra  to madina"},
		{"sentence" : "Pick a car from madina to spintex"}
		]

}

var gmarkers = [];

      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 5.57432, lng: -0.179432
          },
          zoom: 15
        });
      }

      function removeMarkers() {
        for(i = 0 ; i < gmarkers.length; i++ ) {
          gmarkers[i].setMap(null)

        }

      }


      function initAutocomplete() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 5.57432, lng: -0.179432},
          zoom: 15,
          mapTypeId: 'roadmap'
        });

        var marker = new google.maps.Marker({
          position:{
            lat: 5.57432,
            lng: -0.179432
          },
          map:map,
          draggable: false
        })


        var marker1 = new google.maps.Marker({

          map:map,
          draggable: false
        })


        var searchBox1 = new google.maps.places.SearchBox(document.getElementById('map-input'))

        var searchBox2 = new google.maps.places.SearchBox(document.getElementById('map-input1'))

        var destinations = [];

        var S
        var E

        google.maps.event.addListener(searchBox1 , 'places_changed' , function() {

          var places = searchBox1.getPlaces();


          var bounds = new google.maps.LatLngBounds();

          var i , place;

          for (i = 0 ; place=places[i]; i++ ) {


            S = (place.geometry.location.lat())
            E = (place.geometry.location.lng())

            ToSend.startLat = S;
            ToSend.startLng = E;

            destinations.push(new google.maps.LatLng(S , E) );






            bounds.extend(place.geometry.location);
            marker.setPosition(place.geometry.location);
            gmarkers.push(marker);
          }

          map.fitBounds(bounds);
          map.setZoom(15);

        })




        google.maps.event.addListener(searchBox2 , 'places_changed' , function() {

          var places = searchBox2.getPlaces();


          var bounds = new google.maps.LatLngBounds();

          var i , place;

          for (i = 0 ; place=places[i]; i++ ) {

            S = (place.geometry.location.lat())
            E = (place.geometry.location.lng())

            ToSend.endLat  = S;
            ToSend.endLng = E;



            destinations.push(new google.maps.LatLng(S , E) );



            bounds.extend(place.geometry.location);
            marker1.setPosition(place.geometry.location);
            gmarkers.push(marker1);
          }

          map.fitBounds(bounds);
          map.setZoom(12);

          var polylineOptions = {path: destinations,
          strokeColor: "blue" , strokeWeight:4};
          var polyline = new google.maps.Polyline(polylineOptions);
          polyline.setMap(map);

        }
        )}




        document.getElementById("send").addEventListener("click"  , function() {
          console.log(ToSend)
          axios.post( 'http://localhost:8080/getPath',
            ToSend
            ).then(Response=> {
              console.log(Response)
              var distance = document.getElementById("weight")
              distance.textContent  ="Your Total Journey is " +  Response.data.totalD + " Metres";



              Response.data.sentences.forEach(instruction => {
                var card = document.createElement('li');
                card.setAttribute('class' , 'list-group-item');
                card.textContent = instruction.sentence;

                var element = document.getElementById("overhead");
                element.appendChild(card);

              })



            map = new google.maps.Map(document.getElementById('map'), {
              center: {lat: 5.57432, lng: -0.179432
              },
              zoom: 12
            });


          removeMarkers()


          destinations = [];

          Response.data.info.forEach(point => {

            var marker = new google.maps.Marker({
              position:{
                lat: point.lat,
                lng: point.lng
              },
              map:map,
              label: point.label,
              draggable: false
            })


            })





            // gmarkers.push(marker)

            // destinations.push(new google.maps.LatLng(point.lat , point.lng) );

            // var a = new google.maps.LatLng(point.lat , point.lng)

            // map.setCenter(a)





          })








          // var request = new XMLHttpRequest();

          // request.open('POST' , 'https://8dfd5de7-e9f0-4350-9d37-1a20509f9894.mock.pstmn.io/info' , true);
          // request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
          // request.send(ToSend)
          // request.onload = function() {
          //   var data =JSON.parse(this.response);
          //   console.log(data)
          // }





      })


      document.getElementById("sendd").addEventListener('click' , function() {
        location.reload();
      })


      function start() {
        initMap()
        initAutocomplete()
      }
