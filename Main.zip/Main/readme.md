## Instructions to Run

To run the program navigate into the main folder. Open the main folder in a
terminal then run “python3 server.py”. In the browser open the address
http://locahost:8080​. This sends you to the landing page to which you may navigate
the application.

Internet connection is required to fully utilise this application as it calls upon
google services such as google maps API which needs a connection for it to function
properly.

Within the application search for a starting point in the start search box , then
an end point in the end search box ( the search options include the world as this is
google maps api of the world) . Click on the START TRIP button to begin your journey
and the summary table shows all necessary actions to take before you reach your
destination. To begin a new search click on the NEW TRIP button.

