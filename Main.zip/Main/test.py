# while True:
#     lats = int(input())
#     print(lats * 4)

sample = ("435345&&&5.432,-0.654,stop1||9.567,0.432,stop2"
         "||&&&Instruction 1||Instruction 2||")


print(distance)
print(stops)
print(instructions)
